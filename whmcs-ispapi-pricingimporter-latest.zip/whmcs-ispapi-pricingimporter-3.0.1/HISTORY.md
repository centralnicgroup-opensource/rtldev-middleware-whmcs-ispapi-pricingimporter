## [3.0.1](https://github.com/hexonet/whmcs-ispapi-pricingimporter/compare/v3.0.0...v3.0.1) (2018-10-12)


### Bug Fixes

* **psr2:** review code to PSR2 standard ([250f974](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/250f974))

# [3.0.0](https://github.com/hexonet/whmcs-ispapi-pricingimporter/compare/v2.0.0...v3.0.0) (2018-10-11)


### Bug Fixes

* **package.json:** cleanup keywords ([eae0a02](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/eae0a02))
* **package.json:** repository url ([c5189b1](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/c5189b1))
* **script:** add x-bit ([e6cc07c](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/e6cc07c))
* **version:** fix version in main file ([a8bfe75](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/a8bfe75))
* **version:** test release process run ([12742d6](https://github.com/hexonet/whmcs-ispapi-pricingimporter/commit/12742d6))


### BREAKING CHANGES

* **version:** trigger new release as we need to get a release version above 2.4
