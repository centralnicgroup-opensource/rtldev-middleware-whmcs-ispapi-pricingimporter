# [3.0.0](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/compare/v2.0.0...v3.0.0) (2018-10-11)


### Bug Fixes

* **package.json:** cleanup keywords ([eae0a02](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/commit/eae0a02))
* **package.json:** repository url ([c5189b1](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/commit/c5189b1))
* **script:** add x-bit ([e6cc07c](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/commit/e6cc07c))
* **version:** fix version in main file ([a8bfe75](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/commit/a8bfe75))
* **version:** test release process run ([12742d6](https://github.com/hexonet/ispapi_whmcs-pricing-importer-addon/commit/12742d6))


### BREAKING CHANGES

* **version:** trigger next major release as we need to come over v2.4
* **version:** trigger new release as we need to get a release version above 2.4
